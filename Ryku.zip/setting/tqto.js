`
Bara ( Creator )
Tama ( Friend )
zynxzo ( Friend )
LynnZxD ( Creator )
Kiur ( Friend )`
